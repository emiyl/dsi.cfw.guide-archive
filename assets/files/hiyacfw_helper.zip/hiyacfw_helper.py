import os
import subprocess

print('---HIYACFW HELPER---')


print('Decrypting NAND')
try:
    if os.name == 'nt':
        subprocess.call(["twltool", "nandcrypt", "--in", "nand.bin"])
    else:
        print("WARNING: Non-Windows operating system detected!")
        print("The script will continue, but please ensure that Wine is installed.")
        input("Press the Enter key to continue...")
        subprocess.call(["wine", "twltool", "nandcrypt", "--in", "nand.bin"])

except Exception as e:
    print('Error occured! Does this backup have the required NO$GBA footer? ({0})'.format(e))
    input('Press Enter to continue...')       
    exit

print('\nExtracting ARM7/ARM9 BIOS from NAND')
subprocess.call(["wine", "twltool", "boot2", "--in", "nand.bin"])

print('\nIPS patching ARM7/ARM9 BIOS')
if os.name == 'nt':
    subprocess.call(["flips", "--apply", "bootloader files/bootloader arm7 patch.ips", "arm7.bin"])
    subprocess.call(["flips", "--apply", "bootloader files/bootloader arm9 patch.ips", "arm9.bin"])
else: 
    subprocess.call(["wine", "flips", "--apply", "bootloader files/bootloader arm7 patch.ips", "arm7.bin"])
    subprocess.call(["wine", "flips", "--apply", "bootloader files/bootloader arm9 patch.ips", "arm9.bin"])

print('\nPrepending data to ARM9 BIOS')

try:
    with open('bootloader files/bootloader arm9 append to start.bin', 'rb') as arm9_prepend, open('arm9.bin', 'rb') as arm9_bin, open('arm9_new.bin', 'ab') as arm9_new:
        arm9_new.write(arm9_prepend.read() + arm9_bin.read())
    os.remove('arm9.bin')
    os.rename('arm9_new.bin', 'arm9.bin')
except Exception as e:
    print('Error occured! Does the bootloader files folder exist?')
    input('Press Enter to continue...')       
    exit

print('\nGenerating new bootloader')
if os.name == 'nt': 
    subprocess.call(['bootloader files/ndstool', '-c', 'bootloader.nds', '-9', 'arm9.bin', '-7', 'arm7.bin', '-t', 'bootloader files/banner.bin', '-h', 'bootloader files/header.bin'])
else:
    subprocess.call(['wine', 'bootloader files/ndstool', '-c', 'bootloader.nds', '-9', 'arm9.bin', '-7', 'arm7.bin', '-t', 'bootloader files/banner.bin', '-h', 'bootloader files/header.bin'])

# wine twltool modcrypt --in "00000002.app" --out "00000002_dec.app"  
print('\nDecrypting launcher')
if os.name == 'nt':
    subprocess.call(["twltool", "modcrypt", "--in", "00000002.app"])
else:
    subprocess.call(["wine", "twltool", "modcrypt", "--in", "00000002.app"])

print('\nIPS patching launcher')
if os.name == 'nt':
    subprocess.call(["flips", "--apply", "v1.4 Launcher (00000002.app) patch.ips", "00000002.app"])
else:
    subprocess.call(["wine", "flips", "--apply", "v1.4 Launcher (00000002.app) patch.ips", "00000002.app"])

print('\nMoving new files')
if not os.path.isdir('Modified Files'):
    os.mkdir('Modified Files')
os.rename('bootloader.nds', 'Modified Files/bootloader.nds')
os.rename('00000002.app', 'Modified Files/00000002.app')

print('Done!')
print('Navigate to the Modified Files folder.')
print('Copy bootloader.nds to the root of your <2GB SD card.')
print('Copy 00000002.app to title/00030017/484e41XX/content folder on your <2GB SD card.')

